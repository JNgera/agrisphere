<?php
session_start();
include "../config/db.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to raise a dispute!'); window.location.href='../auth/login.php';</script>";
    exit();
}

// Initialize variables
$message = "";
$successMsg = "";
$errorMsg = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = trim($_POST["message"]);

    if (empty($message)) {
        $errorMsg = "Dispute message cannot be empty!";
    } else {
        // Insert into database without status
        $sql = "INSERT INTO disputes (message) VALUES (?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $message);

        if ($stmt->execute()) {
            $successMsg = "Your dispute has been submitted!";
        } else {
            $errorMsg = "Error submitting dispute: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raise a Dispute</title>
    
    <link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->

    <div class="dispute-form">
        <h2>Raise a Dispute</h2>

        <?php if ($successMsg): ?>
            <p style="color: green;"><?php echo $successMsg; ?></p>
        <?php endif; ?>
    
        <?php if ($errorMsg): ?>
            <p style="color: red;"><?php echo $errorMsg; ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="message">Please describe your dispute:</label><br>
            <textarea name="message" id="message" rows="8" required></textarea><br>
            <button type="submit">Submit Dispute</button>
        </form>
    </div>
</body>
</html>
