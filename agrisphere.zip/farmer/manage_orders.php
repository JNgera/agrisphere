<?php
session_start();
if (!isset($_SESSION["user_id"]) ||$_SESSION["role"] !== "farmer") {
    header("Location: ../auth/login.php");
    exit();
}
include "../config/db.php";

$farmer_id = $_SESSION["user_id"];

// Fetch orders related to this farmer
$sql = "SELECT orders.id, users.name AS customer_name, orders.total_price, orders.status
        FROM orders
        JOIN users ON orders.user_id = users.id
        JOIN order_items ON orders.id = order_items.order_id
        JOIN products ON order_items.product_id = products.id
        WHERE products.farmer_id = ?
        GROUP BY orders.id";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
</head>
<body>
    <h2>Manage Orders</h2>
    <table border="1">
        <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Total Price (KES)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echorow["id"]; ?></td>
            <td><?php echo htmlspecialchars(row["customer_name"]); ?></td>
            <td>KES <?php echo number_format(row["total_price"], 2); ?></td>
            <td><?php echo ucfirst(row["status"]); ?></td>
            <td>
                <a href="view_order.php?id=<?php echorow['id']; ?>">View</a> |
                <a href="update_order_status.php?id=<?php echo $row['id']; ?>">Update Status</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>