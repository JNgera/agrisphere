<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "farmer") {
    header("Location: ../auth/login.php");
    exit();
}

include "../../config/db.php";

if (!isset($_GET["id"])) {
    echo "Invalid order ID.";
    exit();
}

$order_id = $_GET["id"];
$farmer_id = $_SESSION["user_id"];

// Fetch order details to ensure the farmer owns the products in this order
$sql = "SELECT orders.status
        FROM orders
        JOIN order_items ON orders.id = order_items.order_id
        JOIN products ON order_items.product_id = products.id
        WHERE orders.id = ? AND products.farmer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $order_id, $farmer_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!order)
    echo "Unauthorized access!";
    exit();

if (_SERVER["REQUEST_METHOD"] == "POST") {
    $new_status = $_POST["status"];

    $update_sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    stmt->bind_param("si",new_status, order_id);
   
    if (stmt->execute()) {
        echo "<script>alert('Order status updated successfully!'); window.location='manage_orders.php';</script>";
    } else {
        echo "Error updating order status.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order Status</title>
</head>
<body>
    <h2>Update Order Status</h2>
    <form method="POST">
        <label for="status">Select Status:</label>
        <select name="status" required>
            <option value="pending" <?php if (order['status'] == 'pending') echo 'selected'; ?>>Pending</option>
            <option value="shipped" <?php if (order['status'] == 'shipped') echo 'selected'; ?>>Shipped</option>
            <option value="delivered" <?php if ($order['status'] == 'delivered') echo 'selected'; ?>>Delivered</option>
        </select>
        <button type="submit">Update</button>
    </form>
    <a href="manage_orders.php">Back</a>
</body>
</html>