<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "farmer") {
 header("Location: ../auth/login.php");
        exit();
    }

?>

<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmer Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION["name"]; ?>!</h2>
    <ul>
        <li><a href="manage_products.php">Manage Products</a></li>
        <li><a href="manage_orders.php">Manage Orders</a></li>
        <li><a href="view_reports.php">View Sales Reports</a></li>
        <li><a href="raise_disputes.php">Raise Disputes</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</body>
</html>