<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "farmer") { 
    header("Location: ../auth/login.php");
    exit();
}

include "../config/db.php";
$farmer_id = $_SESSION["user_id"];
$result = $conn->query("SELECT * FROM products WHERE farmer_id = '$farmer_id'");
?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
</head>
<body>
    <h2>Manage Your Products</h2>
    <a href="add_product.php">+ Add New Product</a>
    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price (KES)</th>
            <th>Category</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
<td><?php echo htmlspecialchars($row["name"]); ?></td>
<td><?php echo htmlspecialchars($row["description"]); ?></td>
<td>KES <?php echo number_format($row["price"], 2); ?></td>
<td><?php echo htmlspecialchars($row["category_id"]); ?></td>
<td><img src="../../uploads/<?php echo $row["image"]; ?>" width="50"></td>
<td>
    <a href="edit_product.php?id=<?php echo $row['id']; ?>">Edit</a> |
    <a href="delete_product.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
</td>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>