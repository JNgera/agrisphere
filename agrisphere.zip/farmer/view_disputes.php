<?php
session_start();
include "../../config/db.php";

// Check if the farmer is logged in
if (!isset($_SESSION['farmer_id'])) {
    echo "<script>alert('Unauthorized access!'); window.location='../../auth/login.php';</script>";
    exit();
}

$farmer_id = $_SESSION['farmer_id'];

// Fetch disputes
$query = "SELECT * FROM disputes WHERE farmer_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Disputes</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <h2>Your Disputes</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Subject</th>
                <th>Description</th>
                <th>Status</th>
                <th>Admin Response</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?= htmlspecialchars(row['subject']) ?></td>
                    <td><?= htmlspecialchars(row['description']) ?></td>
                    <td><?=row['status'] ?></td>
                    <td><?= row['response'] ? htmlspecialchars(row['response']) : 'No response yet' ?></td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>