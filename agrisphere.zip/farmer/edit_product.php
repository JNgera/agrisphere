<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "farmer") {
    header("Location: ../auth/login.php");
    exit();
}

include "../config/db.php";
if (isset($_GET["id"])) {
    $product_id = $_GET["id"];
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
}

?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
</head>
<body>
    <h2>Edit Product</h2>
    
</form>
<input type="hidden" name="id" value="<?php echo $product['id']; ?>">
<input type="text" name="name" value="<?php echo $product['name']; ?>" required>
<textarea name="description"><?php echo $product['description']; ?></textarea>
<input type="number" name="price" step="0.01" value="<?php echo $product['price']; ?>" required>
<label>New Image (optional):</label>
<input type="file" name="image" accept="image/*">
<label>Current Image:</label>
<button type="button" onclick="window.open('../../uploads/<?php echo $product['image']; ?>', '_blank')">
    <img src="../../uploads/<?php echo $product['image']; ?>" width="50">
</button>
<img src="../../uploads/<?php echo $product['image']; ?>" width="50" alt="Current Image">
    <button type="submit">Update Product</button>
    </form>
    <form action="edit_product_process.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="product_id" value="<?php echoproduct_id; ?>">
    <input type="hidden" name="current_image" value="<?php echo $image; ?>">

    <label for="name">Product Name:</label>
 <input type="text" name="name" value="<?php echo htmlspecialchars(name); ?>" required>

    <label for="description">Description:</label>
    <textarea name="description" required><?php echo htmlspecialchars(description); ?></textarea>

    <label for="price">Price (KES):</label>
    <input type="number" step="0.01" name="price" value="<?php echoprice; ?>" required>

    <label for="category">Category:</label>
    <select name="category_id">
        <?php
        $query = "SELECT id, name FROM categories";
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            $selected = ($row['id'] == $category_id) ? "selected" : "";
            echo "<option value='" .row['id'] . "' selected>" . htmlspecialchars(row['name']) . "</option>";
        }
        ?>
    </select>

    <label for="image">Product Image:</label>
    <input type="file" name="image">

    <button type="submit">Update Product</button>
</body>
</html>