<?php
session_start();
include "../config/db.php";

// Check if the farmer is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "farmer") {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch total sales revenue
$query = "SELECT SUM(oi.price * oi.quantity) AS total_revenue, COUNT(DISTINCT o.id) AS total_orders
          FROM orders o
          JOIN order_items oi ON o.id = oi.order_id
          JOIN products p ON oi.product_id = p.id
          WHERE p.farmer_id = ?";

$farmer_id = $_SESSION["user_id"];
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();
$sales_data = $result->fetch_assoc();

// Use ternary operator instead of null coalescing for compatibility
$total_revenue = isset($sales_data['total_revenue']) ? $sales_data['total_revenue'] : 0;
$total_orders = isset($sales_data['total_orders']) ? $sales_data['total_orders'] : 0;

// Fetch list of sold products
$query = "SELECT p.name AS product_name, SUM(oi.quantity) AS quantity_sold, SUM(oi.price * oi.quantity) AS product_revenue
          FROM orders o
          JOIN order_items oi ON o.id = oi.order_id
          JOIN products p ON oi.product_id = p.id
          WHERE p.farmer_id = ?
          GROUP BY p.id";
$farmer_id = $_SESSION["user_id"];

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/farmer_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Revenue Report</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <p><strong>Total Revenue:</strong> KES <?= number_format($total_revenue, 2) ?></p>
    <p><strong>Total Orders:</strong> <?= $total_orders ?></p>

    <h3>Product Sales Breakdown</h3>
    <table border="1">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity Sold</th>
                <th>Total Revenue (KES)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?= htmlspecialchars($row['product_name']) ?></td>
                    <td><?= $row['quantity_sold'] ?></td>
                    <td>KES <?= number_format($row['product_revenue'], 2) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
