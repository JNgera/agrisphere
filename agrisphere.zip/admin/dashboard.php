<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../auth/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
<?php include "../includes/admin_navbar.php"; ?> <!-- Adjust the path as necessary -->
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
    <h2>Welcome, <?php echo $_SESSION["name"]; ?>!</h2>
    <ul>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="view_feedback.php">View Feedback</a></li>
        <li><a href="manage_products.php">Manage Products</a></li>
        <li><a href="orders_overview.php">Orders Overview</a></li>
        <li><a href="view_reports.php">View Reports</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</body>
</html>