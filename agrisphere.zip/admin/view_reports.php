<?php
session_start();
include '../config/db.php';; // Ensure this path is correct

// Check if admin is logged in
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    echo "<script>alert('Unauthorized access!'); window.location='../../auth/login.php';</script>";
    exit();
}
?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<?php include "../includes/admin_navbar.php"; ?> <!-- Adjust the path as necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>

    <h2>Sales Reports</h2>

    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity Sold</th>
                <th>Total Revenue (KES)</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch sales report
            $query = "SELECT
                        p.name AS product_name,
                        SUM(op.quantity) AS total_quantity,
                        SUM(op.quantity * p.price) AS total_revenue
                      FROM order_products op
                      JOIN products p ON op.product_id = p.id
                      JOIN orders o ON op.order_id = o.id
                      WHERE o.order_status = 'Completed'
                      GROUP BY op.product_id";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row['product_name']) . "</td>
                            <td>" . htmlspecialchars($row['total_quantity']) . "</td>
                            <td>KES " . number_format($row['total_revenue'], 2) . "</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No sales data available</td></tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>