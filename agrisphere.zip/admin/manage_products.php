<?php
include '../config/db.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    echo "<script>alert('Unauthorized access!'); window.location='../auth/login.php';</script>";
    exit;
}

// Fetch all products from the database
$sql = "SELECT p.id, p.name, p.description, p.price, c.name AS category, p.image 
        FROM products p
        JOIN categories c ON p.category_id = c.id
        ORDER BY p.id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Admin</title>
    <link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
</head>
<body>
<?php include "../includes/admin_navbar.php"; ?> <!-- Adjust the path as necessary -->
    <h2>Manage Products</h2>
    <a href="add_product.php" class="btn">➕ Add New Product</a>

    <table border="1">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Description</th>
                <th>Price (KES)</th>
                <th>Category</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td>KES <?= number_format($row['price'], 2) ?></td>
                    <td><?= htmlspecialchars($row['category']) ?></td>
                    <td><img src="../uploads/<?= htmlspecialchars($row['image']) ?>" width="50"></td>
                    <td>
                        <a href="edit_product.php?id=<?= $row['id'] ?>" class="btn-edit">✏ Edit</a>
                        <a href="delete_product.php?id=<?= $row['id'] ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this product?');">❌ Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>