<!-- Footer Section -->
<footer class="site-footer">
    <p>&copy; <?php echo date("Y"); ?> Agrisphere. All rights reserved.</p>
</footer>

<!-- Embedded Footer CSS -->
<style>
    .site-footer {
        background-color: rgba(57, 70, 84, 0.96); /* Semi-transparent blue */
        color: white;
        padding: 15px;
        text-align: center;
        background: #0056b3; /* Darker shade of blue */
        position: fixed; /* Fixed position */
        bottom: 0; /* Align to the bottom */
        left: 0; /* Align to the left */
        width: 100%; /* Full width */
        font-size: 14px;
        border-top: 3px solid #007bff; /* Darker shade of blue */
        border-radius: 0; /* No border radius for full width */
        box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2);
    }
</style>