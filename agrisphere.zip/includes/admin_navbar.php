<?php include '../includes/header.php'; ?>
<nav>
    <ul>
        <li><a href="../admin/dashboard.php">Dashboard</a></li>
        <li><a href="../admin/manage_users.php">Manage Users</a></li>
        <li><a href="../admin/view_feedback.php">View Feedback</a></li>
        <li><a href="../admin/manage_products.php">Manage Products</a></li>
        <li><a href="../admin/order_overview.php">Order Overview</a></li>
        <li><a href="../admin/view_reports.php">View Reports</a></li>
        <li><a href="../admin/manage_faqs.php">Manage FAQs</a></li>
        <li><a href="../admin/manage_contacts.php">Manage Messages</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</nav>
<?php include '../includes/footer.php'; ?>