<?php include '../includes/header.php'; ?>
<nav>
    <ul>
        <li><a href="../user/dashboard.php">Dashboard</a></li>
        <li><a href="../user/products.php">View Products</a></li>
        <li><a href="../user/cart.php">View Cart</a></li>
        <li><a href="../user/checkout.php">Checkout</a></li>
        <li><a href="../user/order_status.php">Order Status</a></li>
        <li><a href="../user/contact.php">Contact Us</a></li>
        <li><a href="../user/faqs.php">FAQs</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</nav>
<?php include '../includes/footer.php'; ?>