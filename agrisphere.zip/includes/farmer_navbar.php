<?php include '../includes/header.php'; ?>
<nav>
<ul>
        <li><a href="../farmer/dashboard.php">Dashboard</a></li>
        <li><a href="../farmer/manage_products.php">Manage Products</a></li>
        <li><a href="../farmer/add_product.php">Add Products</a></li>
        <li><a href="../farmer/manage_orders.php">Manage Orders</a></li>
        <li><a href="../farmer/view_reports.php">View Sales Reports</a></li>
        <li><a href="../farmer/raise_disputes.php">Raise Disputes</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</nav>
<?php include '../includes/footer.php'; ?>