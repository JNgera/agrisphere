<?php include '../includes/header.php'; ?>
<?php include '../includes/navbar.php'; ?>

<h1>Welcome to Agrisphere</h1>
<p>Your platform for farm produce sales</p>

<?php include '../includes/footer.php'; ?>