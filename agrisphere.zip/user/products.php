<?php
session_start();
include '../config/db.php'; // Connect to database

// Fetch products from database
$sql = "SELECT p.id, p.name, p.description, p.price, c.name AS category, p.image
        FROM products p
        JOIN categories c ON p.category_id = c.id";
$result = $conn->query($sql);
?>
<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container">
    <h2>Available Products</h2>

    <table border="1">
        <tr>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price (KES)</th>
            <th>Category</th>
            <th>Image</th>
            <th>Action</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td>KES <?php echo number_format($row['price'], 2); ?></td>
                <td><?php echo htmlspecialchars($row['category']); ?></td>
                <td>
                    <img src="../uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="Product Image" width="50">
                </td>
                <td>
                    <form method="post" action="add_to_cart.php">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                        <input type="number" name="quantity" value="1" min="1" required>
                        <button type="submit">Add to Cart</button>
                    </form>
                </td>
            </tr>
        <?php } ?>

    </table>
</div>

</body>
</html>