<?php
session_start();
include '../config/db.php'; // Connect to database

// Redirect if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    echo "<script>alert('Please log in to proceed.'); window.location='../auth/login.php';</script>";
    exit();
}

// Calculate total price
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    $total_price += $item['price'] * $item['quantity'];
}
?>
<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="container">
    <h2>Checkout</h2>
    <form action="process_checkout.php" method="post">
        <label for="address">Delivery Address:</label>
        <input type="text" name="address" required>

        <label for="payment_method">Payment Method:</label>
        <select name="payment_method" required>
            <option value="cash">Cash on Delivery</option>
            <option value="mpesa">M-Pesa</option>
        </select>

        <h3>Total: KES <?php echo number_format($total_price, 2); ?></h3>

        <button type="submit">Place Order</button>
    </form>
</div>

</body>
</html>