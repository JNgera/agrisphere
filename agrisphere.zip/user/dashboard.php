<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "user") {
    header("Location: ../auth/login.php");
    exit();
}
?>

<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION["name"]; ?>!</h2>
    <ul>
        <li><a href="products.php">View Products</a></li>
        <li><a href="cart.php">View Cart</a></li>
 <li><a href="checkout.php">Checkout</a></li>
        <li><a href="order_status.php">Order Status</a></li>
        <li><a href="contact.php">Contact Us</a></li>
        <li><a href="../auth/logout.php">Logout</a></li>
    </ul>
</body>
</html>