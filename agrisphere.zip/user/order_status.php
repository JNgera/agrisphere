<?php
session_start();
include '../config/db.php'; // Database connection

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Unauthorized access! Please login.'); window.location.href='../../auth/login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id']; // Get logged-in user's ID

// Fetch orders for the logged-in user
$sql = "SELECT id, total_price, status, order_date FROM orders WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="../../assets/css/styles.css"> <!-- Include your CSS -->
</head>
<body>

    <div class="container">
        <h2>My Orders</h2>
        <?php
        if ($result->num_rows > 0) {
            echo "<table border='1'>
                    <tr>
                        <th>Order ID</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Order Date</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>KES " . number_format($row['total_price'], 2) . "</td>
                        <td>{$row['status']}</td>
                        <td>{$row['order_date']}</td>
                        <td><a href='view_order.php?order_id={$row['id']}'>View Details</a></td>
                      </tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No orders found.</p>";
        }
        ?>
    </div>
</body>
</html>