<?php
session_start();
include '../config/db.php'; // Connect to database

// Check if cart exists
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total_price = 0;
?>
<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container">
    <h2>Your Cart</h2>

    <?php if (empty($cart)) { ?>
        <p>Your cart is empty.</p>
        <a href="products.php">Continue Shopping</a>
    <?php } else { ?>

        <table border="1">
            <tr>
                <th>Product</th>
                <th>Image</th>
                <th>Price (KES)</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Action</th>
            </tr>

            <?php foreach ($cart as $product_id => $item) {
                $subtotal = $item['price'] * $item['quantity'];
                $total_price += $subtotal; ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" width="50"></td>
                    <td>KES <?php echo number_format($item['price'], 2); ?></td>
                    <td>
                        <form method="post" action="update_cart.php">
                            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1">
                            <button type="submit">Update</button>
                        </form>
                    </td>
                    <td>KES <?php echo number_format($subtotal, 2); ?></td>
                    <td>
                        <a href="remove_from_cart.php?product_id=<?php echo $product_id; ?>" onclick="return confirm('Remove this item?')">Remove</a>
                    </td>
                </tr>
            <?php } ?>

        </table>

        <h3>Total: KES <?php echo number_format($total_price, 2); ?></h3>
        <a href="checkout.php" class="btn">Proceed to Checkout</a>
    <?php } ?>
</div>

</body>
</html>