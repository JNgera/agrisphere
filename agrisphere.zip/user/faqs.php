<?php
session_start();
include '../config/db.php'; // Connect to database

// Fetch FAQs from the database
$query = "SELECT question, answer FROM faqs";
$result = $conn->query($query);

if (!$result) {
    echo "<p>Error fetching FAQs: " . htmlspecialchars($conn->error) . "</p>";
    exit();
}
?>
<?php include '../includes/user_navbar.php'; ?>
<link rel="stylesheet" href="../assets/css/styles.css"> <!-- Adjust if necessary -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<div class="container">
    <h2>Frequently Asked Questions (FAQs)</h2>

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="faq">
            <h3><?php echo htmlspecialchars($row['question']); ?></h3>
            <p><?php echo nl2br(htmlspecialchars($row['answer'])); ?></p>
        </div>
    <?php endwhile; ?>

</div>

</body>
</html>